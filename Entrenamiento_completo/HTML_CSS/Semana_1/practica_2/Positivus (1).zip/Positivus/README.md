## Replicate the figma project Positivus.
### Link https://www.figma.com/community/file/1230604708032389430
