// Simulación de base de datos (json-server)
const API_URL = 'http://localhost:3000'; // Cambia si usas otro puerto

// Utilidades de LocalStorage para sesión
function saveSession(user) {
    localStorage.setItem('session', JSON.stringify(user));
}
function getSession() {
    return JSON.parse(localStorage.getItem('session'));
}
function clearSession() {
    localStorage.removeItem('session');
}

// Renderizado SPA básico
function render(view) {
    document.body.innerHTML = '';
    document.body.appendChild(view);
}

// Formulario de registro
function registerForm() {
    const div = document.createElement('div');
    div.innerHTML = `
        <h2>Registro</h2>
        <form id="register">
            <input name="username" placeholder="Usuario" required><br>
            <input name="password" type="password" placeholder="Contraseña" required><br>
            <select name="role">
                <option value="visitante">Visitante</option>
                <option value="admin">Administrador</option>
            </select><br>
            <button type="submit">Registrarse</button>
        </form>
        <button id="toLogin">Ir a Login</button>
    `;
    div.querySelector('#register').onsubmit = async (e) => {
        e.preventDefault();
        const data = Object.fromEntries(new FormData(e.target));
        // Registro en json-server
        await fetch(`${API_URL}/users`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        alert('Registrado!');
        render(loginForm());
    };
    div.querySelector('#toLogin').onclick = () => render(loginForm());
    return div;
}

// Formulario de login
function loginForm() {
    const div = document.createElement('div');
    div.innerHTML = `
        <h2>Login</h2>
        <form id="login">
            <input name="username" placeholder="Usuario" required><br>
            <input name="password" type="password" placeholder="Contraseña" required><br>
            <button type="submit">Ingresar</button>
        </form>
        <button id="toRegister">Ir a Registro</button>
    `;
    div.querySelector('#login').onsubmit = async (e) => {
        e.preventDefault();
        const data = Object.fromEntries(new FormData(e.target));
        // Autenticación en json-server
        const res = await fetch(`${API_URL}/users?username=${data.username}&password=${data.password}`);
        const users = await res.json();
        if (users.length) {
            saveSession(users[0]);
            routeGuard();
        } else {
            alert('Usuario o contraseña incorrectos');
        }
    };
    div.querySelector('#toRegister').onclick = () => render(registerForm());
    return div;
}

// Home/dashboard
function dashboard() {
    const user = getSession();
    const div = document.createElement('div');
    div.innerHTML = `<h2>Bienvenido, ${user.username} (${user.role})</h2>
        <button id="logout">Cerrar sesión</button>
        <div id="content"></div>
    `;
    div.querySelector('#logout').onclick = () => {
        clearSession();
        routeGuard();
    };
    // Rutas según rol
    if (user.role === 'admin') {
        adminView(div.querySelector('#content'));
    } else {
        visitanteView(div.querySelector('#content'));
    }
    return div;
}

// Vista admin: CRUD eventos
function adminView(container) {
    container.innerHTML = `<h3>Eventos</h3>
        <button id="createEvent">Crear evento</button>
        <ul id="eventList"></ul>
    `;
    loadEvents(container.querySelector('#eventList'));
    container.querySelector('#createEvent').onclick = () => render(eventForm());
}

function loadEvents(list) {
    fetch(`${API_URL}/events`).then(r => r.json()).then(events => {
        list.innerHTML = '';
        events.forEach(ev => {
            const li = document.createElement('li');
            li.innerHTML = `<strong>${ev.nombre}</strong> (${ev.capacidad} lugares)<br><em>${ev.descripcion || ''}</em>`;
            li.innerHTML += ` <button data-id="${ev.id}" class="edit">Editar</button> <button data-id="${ev.id}" class="delete">Eliminar</button>`;
            list.appendChild(li);
        });
        list.querySelectorAll('.edit').forEach(btn => {
            btn.onclick = () => render(eventForm(btn.dataset.id));
        });
        list.querySelectorAll('.delete').forEach(btn => {
            btn.onclick = async () => {
                await fetch(`${API_URL}/events/${btn.dataset.id}`, { method: 'DELETE' });
                loadEvents(list);
            };
        });
    });
}

// Formulario crear/editar evento
function eventForm(id = null) {
    const div = document.createElement('div');
    div.innerHTML = `<h3>${id ? 'Editar' : 'Crear'} Evento</h3>
        <form id="eventForm">
            <input name="nombre" placeholder="Nombre" required><br>
            <input name="descripcion" placeholder="Descripción" required><br>
            <input name="capacidad" type="number" placeholder="Capacidad" required><br>
            <button type="submit">${id ? 'Actualizar' : 'Crear'}</button>
        </form>
        <button id="back">Volver</button>
    `;
    if (id) {
        fetch(`${API_URL}/events/${id}`).then(r => r.json()).then(ev => {
            div.querySelector('[name=nombre]').value = ev.nombre;
            div.querySelector('[name=descripcion]').value = ev.descripcion || '';
            div.querySelector('[name=capacidad]').value = ev.capacidad;
        });
    }
    div.querySelector('#eventForm').onsubmit = async (e) => {
        e.preventDefault();
        const data = Object.fromEntries(new FormData(e.target));
        if (id) {
            await fetch(`${API_URL}/events/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
        } else {
            await fetch(`${API_URL}/events`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ...data, registrados: [] })
            });
        }
        render(dashboard());
    };
    div.querySelector('#back').onclick = () => render(dashboard());
    return div;
}

// Vista visitante: ver y registrarse en eventos
function visitanteView(container) {
    container.innerHTML = `<h3>Eventos disponibles</h3>
        <ul id="eventList"></ul>
    `;
    fetch(`${API_URL}/events`).then(r => r.json()).then(events => {
        const list = container.querySelector('#eventList');
        list.innerHTML = '';
        events.forEach(ev => {
            const li = document.createElement('li');
            li.innerHTML = `<strong>${ev.nombre}</strong> (${ev.capacidad} lugares)<br><em>${ev.descripcion || ''}</em>`;
            const user = getSession();
            const registrados = ev.registrados || [];
            const registrado = registrados.includes(user.username);
            if (registrado) {
                li.innerHTML += ' (Registrado) <button data-id="' + ev.id + '" class="unreg">Eliminar registro</button>';
            } else {
                li.innerHTML += ` <button data-id="${ev.id}" class="reg">Registrarse</button>`;
            }
            list.appendChild(li);
        });
        // Botón para registrarse
        list.querySelectorAll('.reg').forEach(btn => {
            btn.onclick = async () => {
                const user = getSession();
                const res = await fetch(`${API_URL}/events/${btn.dataset.id}`);
                const evento = await res.json();
                if ((evento.registrados || []).length < evento.capacidad) {
                    await fetch(`${API_URL}/events/${btn.dataset.id}`, {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ registrados: [...(evento.registrados || []), user.username] })
                    });
                    alert('Registrado en el evento!');
                    visitanteView(container);
                } else {
                    alert('Evento lleno');
                }
            };
        });
        // Botón para eliminar registro
        list.querySelectorAll('.unreg').forEach(btn => {
            btn.onclick = async () => {
                const user = getSession();
                const res = await fetch(`${API_URL}/events/${btn.dataset.id}`);
                const evento = await res.json();
                const nuevosRegistrados = (evento.registrados || []).filter(u => u !== user.username);
                await fetch(`${API_URL}/events/${btn.dataset.id}`, {
                    method: 'PATCH',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ registrados: nuevosRegistrados })
                });
                alert('Registro eliminado!');
                visitanteView(container);
            };
        });
    });
}

// Ruta protegida y lógica de navegación
function routeGuard() {
    const user = getSession();
    if (!user) {
        render(loginForm());
    } else {
        render(dashboard());
    }
}

// Persistencia de sesión al recargar
window.onload = routeGuard;
